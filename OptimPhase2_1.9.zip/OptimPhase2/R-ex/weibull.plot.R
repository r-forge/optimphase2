### Name: weibull.plot
### Title: Plot Weibull Survival Curves
### Aliases: weibull.plot
### Keywords: hplot

### ** Examples

param <- c(1, 1.09, 2, 1.40)
x <- 1

weibull.plot(param,x)




